import React from 'react'

function Product() {
  return (
    <div>Product</div>
  )
}

export default Product
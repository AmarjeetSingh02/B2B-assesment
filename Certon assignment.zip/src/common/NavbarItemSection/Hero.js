import React from 'react'

function Hero() {
  return (
    <div>Hero</div>
  )
}

export default Hero
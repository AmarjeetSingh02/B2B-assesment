const Tdata = [
  {
    cover: "./images/top/category-1.png",
    para: "headphone",
  },
  {
    cover: "./images/top/category-2.png",
    para: "watch",
  },
  {
    cover: "./images/top/category-3.png",
    para: "sunglass",
  },
  {
    cover: "./images/top/category-2.png",
    para: "watch",
  },
  {
    cover: "./images/top/category-3.png",
    para: "sunglass",
  },
]

export default Tdata
